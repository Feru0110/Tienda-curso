/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import com.parcial_1.domain.moto;
import com.parcial_1.service.impl.FirebaseStorageServiceImpl;
import com.pparcial_1.service.MotoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author feru0
 */
@Controller
@RequestMapping("/moto")
public class IndexController {
    
    @Autowired
    private MotoService motoService;

    @GetMapping("/listado")
    private String listado(Model model) {
        var motos = motoService.getMotos();
        model.addAttribute("motos", motos);
        model.addAttribute("totalMotos", motos.size());
        return "moto/listado";
    }

    @GetMapping("/nuevo")
    public String nuevaMoto(moto moto) {
        return "/moto/modifica";
    }
    
    @Autowired
    private FirebaseStorageServiceImpl firebaseStorageService;

    @PostMapping("/guardar")
    public String guardarMoto(moto moto, @RequestParam("imagenFile") MultipartFile imagenFile) {
        if (!imagenFile.isEmpty()) {
            motoService.save(moto);
            moto.setRutaImagen(
                    firebaseStorageService.cargaImagen(
                            imagenFile,
                            "moto",
                            moto.getIdMoto()));
        }
        motoService.save(moto);
        return "redirect:/moto/listado";
    }

    @GetMapping("/eliminar/{idMoto}")
    public String eliminarMoto(@PathVariable int idMoto, Model model) {
        motoService.delete(idMoto);
        return "redirect:/moto/listado";
    }

    @GetMapping("/modifica/{idMoto}")
    public String modificarMoto(moto moto, Model model) {
        moto = motoService.getMoto(moto);
        model.addAttribute("moto", moto);
        return "moto/modifica";
    }

}

