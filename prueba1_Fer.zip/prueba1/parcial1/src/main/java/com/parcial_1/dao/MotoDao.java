/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.parcial_1.dao;

import com.parcial_1.domain.moto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Feru0110
 */
@Repository

public interface MotoDao extends JpaRepository <moto,Long> { //long = id
    //crea una capa de datos que extiende a la clase creada, es decir, jala la info de los atributos

}
