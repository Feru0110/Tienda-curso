/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.parcial_1.domain;

import jakarta.persistence.*;
import java.io.Serializable;
import lombok.Data;



@Data
@Entity
@Table(name = "moto")


public class moto implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_moto")

    private long idMoto;
    private String marcaMoto;
    private int cilindrada;
    private double precio;
    private String rutaImagen;

    public moto() {

    }

    public moto(long idMoto, String marcaMoto, int cilindrada, double precio, String rutaImagen) {
        this.idMoto = idMoto;
        this.marcaMoto = marcaMoto;
        this.cilindrada = cilindrada;
        this.precio = precio;
        this.rutaImagen = rutaImagen;
    }



}
