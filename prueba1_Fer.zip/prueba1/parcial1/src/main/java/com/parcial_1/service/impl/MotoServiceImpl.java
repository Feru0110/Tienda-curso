package com.parcial_1.service.impl;



import com.parcial_1.dao.MotoDao;
import com.parcial_1.domain.moto;
import com.pparcial_1.service.MotoService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service

public class MotoServiceImpl implements MotoService {

    @Autowired
    public MotoDao motoDao;

    @Override
    @Transactional(readOnly = true)
    public List<moto> getMotos() {
        var lista = motoDao.findAll();
        return lista;
    }

    @Override
    @Transactional(readOnly = true)
    //obtener un arbol segun una categoria
    public moto getMoto(moto moto) {
        return motoDao.findById(moto.getIdMoto()).orElse(null);

    }

    @Override
    @Transactional
    public void save(moto arbol) {
        motoDao.save(arbol);
    }

    @Override
    public void delete(int id) {
        motoDao.deleteById((long)id);
    }



}
