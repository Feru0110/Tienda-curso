/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.pparcial_1.service;

import com.parcial_1.domain.moto;
import java.util.List;

public interface MotoService {
    
    //esta list es para traer todos los arboles
    public List<moto> getMotos();
    
    //obtener un arbol segun una categoria
    public moto getMoto(moto moto);
    
    public void save(moto moto);
    
    public void delete(int id);
    
}
